import ai.djl.MalformedModelException;
import ai.djl.Model;
import ai.djl.modality.Classifications;
import ai.djl.modality.cv.Image;
import ai.djl.modality.cv.ImageFactory;
import ai.djl.modality.cv.transform.Resize;
import ai.djl.modality.cv.transform.ToTensor;
import ai.djl.ndarray.NDList;
import ai.djl.translate.*;
//import ai.djl.translate.TranslatorRegistry;
//import ai.djl.translate.TranslatorUtils;
import ai.djl.util.Utils;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

public class NationalIDCardExtractor {

    public static void main(String[] args) throws IOException, TranslateException, MalformedModelException {
        Path modelDir = Paths.get("models/national_id_card");  // Path to the saved model
        String modelName = "national_id_card";

        // Load the trained model
        try (Model model = Model.newInstance(modelName)) {
            model.load(modelDir);
            // Create a translator for preprocessing and postprocessing
            IDCardTranslator translator = new IDCardTranslator();

            // Load the predictor
            try (var predictor = model.newPredictor(translator)) {
                // Process a sample image (replace "sample.jpg" with your test image path)
                Path imagePath = Paths.get("sample.jpg");
                Image image = ImageFactory.getInstance().fromFile(imagePath);

                // Run inference
                Classifications result = predictor.predict(image);

                // Output results
                System.out.println("Prediction: " + result);
            }
        }
    }

    // Custom Translator for National ID Card detection
    static class IDCardTranslator implements Translator<Image, Classifications> {

        @Override
        public NDList processInput(TranslatorContext ctx, Image input) {
            // Preprocess the input image: Resize and normalize
            input.getTransform().add(new Resize(256, 256));
            input = input.toTensor(ctx.getNDManager())
                    .resize(256, 256)
                    .toTensor();
            return new NDList(input.toNDArray(ctx.getNDManager()));
        }

        @Override
        public Classifications processOutput(TranslatorContext ctx, NDList list) {
            // Convert model output into Classifications
            return new Classifications(ctx.getModel().getProperty("classes", ""), list.singletonOrThrow());
        }

        @Override
        public Batchifier getBatchifier() {
            // Allows batching of inputs
            return Batchifier.STACK;
        }
    }
}
